package Validator;

import java.util.List;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.model.dstu2.resource.OperationOutcome;
import ca.uhn.fhir.validation.FhirValidator;
import ca.uhn.fhir.validation.IValidatorModule;
import ca.uhn.fhir.validation.SchemaBaseValidator;
import ca.uhn.fhir.validation.SingleValidationMessage;
import ca.uhn.fhir.validation.ValidationResult;
import ca.uhn.fhir.validation.schematron.SchematronBaseValidator;

public class ValidationClass {
	public int readData(String struct,String card, String valDo, String cons,String structRes,String res) throws Exception{
		System.out.println("struct = " + struct);
		System.out.println("Structure = " + structRes);
		System.out.println("Resource = "+ res);
		
		FhirContext ctx = FhirContext.forDstu2();
		FhirValidator vard = ctx.newValidator();
		IValidatorModule module1 = new SchemaBaseValidator(ctx);
		IValidatorModule module2 = new SchematronBaseValidator(ctx);
		vard.registerValidatorModule(module1);
		vard.registerValidatorModule(module2);
		ValidationResult result = vard.validateWithResult(res);
		if (result.isSuccessful()) {
		    
			   System.out.println("Validation passed");
			    
			} else {
			   // We failed validation!
			   System.out.println("Validation failed");
			}
			 
			// The result contains a list of "messages"
			List<SingleValidationMessage> messages = result.getMessages();
			for (SingleValidationMessage next : messages) {
			   System.out.println("Message:");
			   System.out.println(" * Location: " + next.getLocationString());
			   System.out.println(" * Severity: " + next.getSeverity());
			   System.out.println(" * Message : " + next.getMessage());
			}
			 
			// You can also convert the results into an OperationOutcome resource
			OperationOutcome oo = (OperationOutcome) result.toOperationOutcome();
			String results = ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(oo);
			System.out.println(results);
		System.out.println("Result = "+ result);
		return 0;
	}
}
