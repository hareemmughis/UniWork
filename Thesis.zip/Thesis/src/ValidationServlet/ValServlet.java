package ValidationServlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Validator.ValidationClass;

/**
 * Servlet implementation class ValServlet
 */
@WebServlet("/ValServlet")
public class ValServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		  String struct = request.getParameter("Structure");
		  String card = request.getParameter("Cardinalities");
		  String valDo = request.getParameter("ValueDomain");
		  String cons = request.getParameter("Constraints");
		  String structRes = request.getParameter("StructureResource");
		  String res = request.getParameter("Resource");
		  int iRowAffected = 5;   
		  ValidationClass val = new ValidationClass();
		  try {
			val.readData(struct,card,valDo,cons,structRes,res);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
